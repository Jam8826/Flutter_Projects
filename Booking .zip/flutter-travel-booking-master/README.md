# flutter_travel_booking

A Flutter Travel Booking app UI concept

## Design

This design UI is inspire from https://dribbble.com/shots/6510521-Travel-App-for-booking-unique-experience

## App UI

<a href="https://imgflip.com/gif/38wkd7"><img src="https://i.imgflip.com/38wkd7.gif" title="made at imgflip.com"/></a>

HomePage             |  Detail     
:-------------------------:|:-------------------------:
<img src="lib/images/home.png" alt="home" width="500"/>  |  <img src="lib/images/detail.png" alt="order" width="500"/>




 


