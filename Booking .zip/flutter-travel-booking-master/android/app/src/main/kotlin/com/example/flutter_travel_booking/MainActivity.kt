package com.lynical.travelbooking

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
