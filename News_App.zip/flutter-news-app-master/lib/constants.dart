const Map<String, String> Constants = const {
  'API_BASE_URL': '<ROOT_URL>/wp-json/wp/v2'
};
