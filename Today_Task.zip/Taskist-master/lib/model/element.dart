class ElementTask{
  final String name;
  final bool isDone;

  ElementTask(this.name, this.isDone);

}