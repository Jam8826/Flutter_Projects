package com.example.sgpa_calc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
